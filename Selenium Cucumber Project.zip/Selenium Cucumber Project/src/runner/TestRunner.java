package runner;
import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@Cucumber.Options(features="feature files",glue={"stepDefinitions"})

public class TestRunner {

}
