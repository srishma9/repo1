package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Smoketest {
	WebDriver driver;
	
	@Given("^Open firefox and start application$")
	public void Open_firefox_start_application() throws Throwable{
	driver=new FirefoxDriver();
	System.setProperty("webdriver.gecko.driver","C:\\Users\\Srishma\\Downloads\\geckodriver-v0.14.0-win64\\geckodriver.exe");
	driver.manage().window().maximize();
	driver.get("http://www.facebook.com");
	}
    @When("^I enter valid \"([^\"]*)" and valid \"([^\"]*)"$")
    public void I_enter_valid_username_andvalid_password(String uname, String pass) throws Throwable{
    	driver.findElement(By.id("email")).sendKeys("madhavaramsrishma@gmail.com");
    	driver.findElement(By.id("pass")).sendKeys("Srishma123");
    	
    	
    }
    @Then("^user should be able to login successfully$")
    public void user_should_be_able_to_login_successfully() throws Throwable{
	driver.findElement(By.id("loginbutton")).click();
}
}
