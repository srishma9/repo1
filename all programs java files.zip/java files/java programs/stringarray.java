public class stringarray {

   public static void main(String[] args) {
      String[] myList = {"a", "b", "c", "d"};

      // Print all the array elements
      for (int i = 0; i < myList.length; i++) {
         System.out.println(myList[i] + " ");
      }
     
   }
}

      // Summing all elements
      
      