package employee;
interface Salary {
	void salaryTotal();
	void bonus();
}
