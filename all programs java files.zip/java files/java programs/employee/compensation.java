package employee;

public class compensation implements Salary{
	public void salaryTotal(){
		System.out.println("this is salry of the employee");
	}

	@Override
	public void bonus() {
		// TODO Auto-generated method stub
		System.out.println("this is bonus of the employee");
	}
		

public static void main(String args[]){
	compensation c=new compensation();
	c.bonus();
	c.salaryTotal();
}
}
	


