package sqlselection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Sqlselection 
    {
        public static void main(String[] args)
        {
            try
            {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

                String userName = "sa";
                String password = "pwd123";
                String url = "jdbc:sqlserver://localhost;user=sa;password=pwd123;database=testDB";
                Connection con = DriverManager.getConnection(url, userName, password);
                Statement s1 = con.createStatement();
                ResultSet rs = s1.executeQuery("select NAME FROM CUSTOMERS");
                String[] result = new String[2];
                if(rs!=null){
                    while (rs.next()){
                        for(int i = 1; i <result.length ;i++)
                        {
                            for(int j = 1; j <result.length;j++)
                            {
                                result[j]=rs.getString(i);
                            System.out.println(result[j]);
                        }
                        }
                    }
                }

                //String result = new result[20];

            } catch (Exception e)
            {
                e.printStackTrace();
            }
    }


}

