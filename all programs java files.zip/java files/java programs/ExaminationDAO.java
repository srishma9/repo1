import java.sql.*;
import java.util.*;
import java.util.Map.Entry;

public class ExaminationDAO {
	public static void main(String args[]){
	

	Connection connDB = null;
	PreparedStatement pstmt = null;
		connDB = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			//connDB = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;user=sa;password=pwd123;databaseName=OnlineExaminationSystem");
			
			connDB = DriverManager.getConnection("jdbc:sqlserver://localhost;user=sa;password=pwd123;database=testDB");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	
	}

	//Login validation against the onlineExamination DB
	public String loginValidation(String id){
		String type = "invalid";
		try{
			System.out.println("step1");
			Connection conn = getConnection();
			PreparedStatement pstmt = conn.prepareStatement("select max(ID) FROM CUSTOMERS");
			ResultSet rs = pstmt.executeQuery();
			rs.close();
			conn.close();

		}//End of try block
		catch(Exception e)
		{
			System.out.println("Exception occured in validating the login");
			e.printStackTrace();
		}
		return type;
	}

	private Connection getConnection() {
		return null;
	}
}


	
