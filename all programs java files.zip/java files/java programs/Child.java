class parent {
 public void work() {
  System.out.println("Parent is under retirement from work.");
 }
}
class Child extends parent {
 public void work() {
  System.out.println("Child has a job");
  System.out.println(" He is doing it well");    
  }
  public static void main(String argu[]) {
   Child c1 = new Child();
   c1.work();
  }
 }
