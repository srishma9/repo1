 class stud {
 // Methods cannot be extended to its sub class//use final to expian
	 
}
class Books extends stud {
 void show() {
  System.out.println("Book-Class method");
 }
 public static void main(String args[]) {
  Books B1 = new Books();
  B1.show();
 }
}