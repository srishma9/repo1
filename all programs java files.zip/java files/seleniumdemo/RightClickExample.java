package seleniumdemo;

public class RightClickExample {

}
