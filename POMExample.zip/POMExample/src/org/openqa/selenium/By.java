package org.openqa.selenium;

public class By {

	public static By name(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public static By className(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
