package org.openqa.selenium;

public class WebDriver {

	public Object findElement(By user99GuruName) {
		// TODO Auto-generated method stub
		return null;
	}

}
