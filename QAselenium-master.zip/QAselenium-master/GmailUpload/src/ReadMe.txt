Check config.properties file for key value pair changes like username and password
please provide your autoit compiles file path to execute correctly