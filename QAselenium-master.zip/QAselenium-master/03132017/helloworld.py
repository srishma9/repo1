print ("hello world")
age=2
street=20.001
city="carrollton"
cityone="hello"
print (int(street))
print (str(street))
var = 123
if (var==123) :
    print ("var is 123")
else :
    print ("var is not 123")
str = "welcome"
if "s" in str :
    print ("s is present")
else :
    print ("s is not present")
# print number from one to 10
for i in range(1,11) : # java version for(int i=1;i<11;i++)
    print(i)
print("oye")
    
wel="welcome"
for j in wel :
    print(j) 
count=0
while (count<5) :
    print (count)
    count=count+1
 #String Functions
city="carrollton city"
print(city[0]) 
print(city[3:7]) 
print (city + cityone)

#List data type
list =[1,2,3,4,5,6,6,7,"hello"]
list.append(10)
print(list)
print (list.count(6))
print (list.index(5))
list.remove(6)
print (list)
list.reverse()
print (list)